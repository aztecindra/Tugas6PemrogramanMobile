<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/main.css" type="text/css">
	</head>
<body>
	<div id="wrapper">
			<?php include("header.php"); ?>
			<div id="content" class="checkout">
				<div id="breadcrumb">
					<a href="#">Daftar Produk</a>
				</div>
				<?php include("left.php"); ?>
				<div id="right">
					<h1 class="bar">Produk<a  style="float:right;" href="<?php echo base_url();?>index.php/admin/add_product">Tambah Produk Baru</a></h1>
                    <?php if($products=='empty')
					echo " Maaf - Produk Tidak Ditemukan";
					else
					{
						?>
					<table id="cart">
						<thead>
							<th class="thumb-column">Gambar</th>
							<th>Nama</th>
							<th>Jumlah</th>
							<th>Harga</th>
							<th>Aksi</th>
						</thead>
						<tbody>
                        <?php foreach($products as $product)
						{
							?>
							<tr>
								<td><img src="<?php echo base_url();?>	<?php echo $product->thumbnail;?>" alt="" /></td>
								<td align=""><?php echo $product->item_name;?></td>
								<td align="center"><?php echo $product->item_stock;?></td>
								<td align="right">Rp. <?php echo number_format($product->item_price,2,',','.');?></td>
								<td align="center"><a href="<?php echo base_url();?>">Veiw</a> | 
                                <a href="<?php echo base_url();?>index.php/admin/edit_product/<?php echo $product->item_id;?>">Edit</a> | 
                                <a href="<?php echo base_url();?>index.php/admin/delete_product/<?php echo $product->item_id;?>">Delete</a></td>
							</tr>
                            <?php } ?>
							
						</tbody>
					</table>
                                        <?php 
                                        if($total>RECORDS_PER_PAGE)
                                        {
                                        $pages = ceil($total/RECORDS_PER_PAGE);
                                        
                                        ?>
					<div id="actions">
						<div id="pagination">
							<a href="">&laquo;</a>
							<?php for($i=1; $i<=$pages;$i++)
                                                        {
                                                            ?><a class="<?php if($this->uri->segment(3)==$i) echo 'active';?>" href="<?php echo base_url();?>index.php/admin/products/<?=$i;?>"><?php echo $i;?></a>
                                                            
                                                          <?php } ?>  
							<a href="">&raquo;</a>
						</div>
                                           <?php } ?> 
                        	<?php } ?>
					</div>
				</div>
<div class="clear"></div>
			<?php include("footer.php"); ?>
			</div>
	
	</div>
</body>
</html>