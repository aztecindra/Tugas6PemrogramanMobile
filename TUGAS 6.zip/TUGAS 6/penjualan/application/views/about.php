<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/main.css" type="text/css">
	</head>
<body>
	<div id="wrapper">
			<?php include("header.php"); ?>
			<div id="content">

				<?php include("left.php"); ?>
				<div id="right">
					<h1 class="bar">Tentang Kami</h1>
                    <p>Kami Benteng Land hadir untuk memenuhi hunian Anda.
					<p>Hunian nyaman dengan lokasi yang sangat strategis dan fasilitas yang aman. 
					<p>Untuk info lebih lanjut hubungi kami di (0471)346785 (Yuni) atau 081243036609
					<div class="clear"></div>
					</br>Salam Benteng Land.
				
			  </div>		
				<div class="clear"></div>
				<?php include("footer.php"); ?>
			</div>
	
	</div>
</body>
</html>